package org.example;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMediaGroup;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.media.InputMedia;
import org.telegram.telegrambots.meta.api.objects.media.InputMediaPhoto;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import javax.print.SimpleDoc;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MyBot extends TelegramLongPollingBot {
    private MyBotServis myBotServis=new MyBotServis();

    @Override
    public void onUpdateReceived(Update update) {


        if (update.hasMessage() && update.getMessage().hasText()){
            Long chatId = update.getMessage().getChatId();
            String text = update.getMessage().getText();

            String firstName = update.getMessage().getChat().getFirstName();
            String lastName = update.getMessage().getChat().getLastName();
            Long id = update.getMessage().getChat().getId();




            info(firstName,lastName,id,text);

            if (text.equals("/photos")){

                InputMediaPhoto inputMediaPhoto = new InputMediaPhoto();
                InputMediaPhoto inputMediaPhoto1 = new InputMediaPhoto();
                InputMediaPhoto inputMediaPhoto2 = new InputMediaPhoto();
                List<InputMedia> photos=new ArrayList<>();

                photos.add(inputMediaPhoto);
                photos.add(inputMediaPhoto1);
                photos.add(inputMediaPhoto2);

                SendMediaGroup sendMediaGroup = new SendMediaGroup();
                sendMediaGroup.setChatId(update.getMessage().getChatId());
                sendMediaGroup.setMedias(photos);

                try {
                    execute(sendMediaGroup);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }


            }



            if (text.equals("/start")){
                try {
                    execute(myBotServis.replyMarkub(chatId));
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }

            if (text.equals("\uD83C\uDDFA\uD83C\uDDFFOzbek tilli")){
                try {
                    execute(myBotServis.replyMark2(chatId));
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }
            if (text.equals("\uD83C\uDDF7\uD83C\uDDFARuss tilli")){
                try {
                    execute(myBotServis.replyMark3(chatId));
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            if (text.equals("Manzilimiz")){
                try {
                    execute(myBotServis.sendLocation(chatId));
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }




        }


    }

    @Override
    public String getBotUsername() {
        return "PDP_Rasmiy_bot";
    }

    @Override
    public String getBotToken() {
        return "6863196086:AAHrnWdkYALAnhIiz5BR7kDC_-TXVLd6OnU";
    }

    private void info(String firstName,String lastName,Long id,String text){
        System.out.println("---------------");

        DateFormat dateFormat=new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss");




        System.out.println("FirstName" + firstName+"\n"+"LastName"+"\n"+"ID"+id+"\n"+"text"+text );
    }
}
